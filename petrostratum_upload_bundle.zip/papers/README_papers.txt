Use this folder for empirical_results_section.md and manuscript drafts.
