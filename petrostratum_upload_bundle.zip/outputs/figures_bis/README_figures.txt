This folder is reserved for validation outputs such as event_study_*.png, roc_comparison.png, and threshold_curve.png generated after running validation_engine_v4.
