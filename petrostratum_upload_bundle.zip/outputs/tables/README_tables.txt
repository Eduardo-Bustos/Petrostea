This folder is reserved for exported validation tables such as state_panel_final.csv, rolling_window_summary.csv, rolling_predictions.csv, and threshold_table.csv.
