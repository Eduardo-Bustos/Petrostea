# Empirical Results — Validation v4

## 1. Integrated panel
The validation layer integrates master state metrics, market transmission windows and event-aligned studies into a single auditable panel.

## 2. Predictive comparison
Report rolling out-of-sample AUC, F1 and accuracy for:
- baseline model
- full execution-coherence model

## 3. Threshold calibration
Discuss the threshold that maximizes F1 and whether it corresponds to a fragile-to-binding transition zone.

## 4. Event response
Assess whether SG, Theta_eff, CP_eff and ALT_EXEC_emp show systematic pre/post movement around registered events.
