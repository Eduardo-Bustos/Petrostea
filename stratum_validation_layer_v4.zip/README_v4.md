# STRATUM Validation Layer v4

This bundle includes:
- validation/validation_engine_v4.py
- validation/streamlit_validation_v4_patch.py
- papers/empirical_results_section_v4_template.md

## Purpose
Integrate multiple Excel / CSV state tables, align event studies, construct ALT_EXEC_emp, compare full vs baseline models, optimize thresholds and export BIS-style outputs.
