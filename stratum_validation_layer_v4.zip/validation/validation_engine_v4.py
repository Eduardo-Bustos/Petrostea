
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve, confusion_matrix

@dataclass
class DataSourceConfig:
    dataset_master_path: str | None = None
    merged_master_path: str | None = None
    state_metrics_path: str | None = None
    transmission_window_path: str | None = None
    event_paths: list[str] = field(default_factory=list)
    scenarios_path: str | None = None
    simulated_paths_path: str | None = None

@dataclass
class ValidationV4Config:
    date_col: str = "date"
    event_date_col: str = "event_date"
    event_flag_col: str = "event_flag"
    target_col: str = "binding_future"
    feature_cols_full: tuple[str, ...] = ("Stress","SG_tau","Theta_eff","FAI","R_star","ALT_EXEC_emp","CP_eff")
    feature_cols_baseline: tuple[str, ...] = ("Stress","SG_tau")
    rolling_window: int = 80
    rolling_step: int = 5
    event_pre_window: int = 5
    event_post_window: int = 5
    threshold_grid_size: int = 201
    output_dir: str = "outputs/validation_v4"

def load_table(path, sheet_name=0):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    if path.suffix.lower() in {".xlsx",".xls"}:
        return pd.read_excel(path, sheet_name=sheet_name)
    raise ValueError(f"Unsupported file type: {path.suffix}")

def normalize_column_names(df):
    out = df.copy()
    out.columns = [str(c).strip().replace(" ","_").replace("-","_").replace("/","_") for c in out.columns]
    return out

def coerce_datetime(df, candidates):
    out = df.copy()
    for c in candidates:
        if c in out.columns:
            out[c] = pd.to_datetime(out[c], errors="coerce")
    return out

def load_and_harmonize_sources(ds_cfg, cfg):
    tables = {}
    def _load_optional(label, path):
        if path:
            df = load_table(path)
            df = normalize_column_names(df)
            df = coerce_datetime(df, [cfg.date_col, cfg.event_date_col])
            tables[label] = df
    _load_optional("dataset_master", ds_cfg.dataset_master_path)
    _load_optional("merged_master", ds_cfg.merged_master_path)
    _load_optional("state_metrics", ds_cfg.state_metrics_path)
    _load_optional("transmission_window", ds_cfg.transmission_window_path)
    _load_optional("scenarios", ds_cfg.scenarios_path)
    _load_optional("simulated_paths", ds_cfg.simulated_paths_path)
    event_frames = []
    for p in ds_cfg.event_paths:
        ev = load_table(p)
        ev = normalize_column_names(ev)
        ev = coerce_datetime(ev, [cfg.date_col, cfg.event_date_col])
        event_frames.append(ev)
    if event_frames:
        tables["events"] = pd.concat(event_frames, axis=0, ignore_index=True).drop_duplicates()
    return tables

def build_master_state_panel(tables, cfg):
    candidates = []
    for label in ["dataset_master","merged_master","state_metrics","transmission_window"]:
        if label in tables:
            df = tables[label].copy()
            if cfg.date_col in df.columns:
                candidates.append(df)
    if not candidates:
        raise ValueError("No state-like table with a date column was found.")
    candidates = sorted(candidates, key=lambda x: x.shape[1], reverse=True)
    master = candidates[0].copy()
    for df in candidates[1:]:
        if cfg.date_col not in df.columns or cfg.date_col not in master.columns:
            continue
        merge_cols = [c for c in df.columns if c not in master.columns or c == cfg.date_col]
        master = master.merge(df[merge_cols], on=cfg.date_col, how="outer", suffixes=("","_dup"))
    master = normalize_column_names(master)
    master = coerce_datetime(master, [cfg.date_col]).sort_values(cfg.date_col).dropna(subset=[cfg.date_col]).reset_index(drop=True)
    dup_cols = [c for c in master.columns if c.endswith("_dup")]
    if dup_cols:
        master = master.drop(columns=dup_cols)
    for src, dst in {"SG":"SG_tau","Theta":"Theta_tau","Phi":"Phi_tau"}.items():
        if dst not in master.columns and src in master.columns:
            master[dst] = master[src]
    return master

def align_events_to_panel(state_df, events_df, cfg):
    out = state_df.copy()
    out[cfg.event_flag_col] = 0
    if events_df is None or events_df.empty:
        return out
    events = normalize_column_names(events_df)
    events = coerce_datetime(events, [cfg.event_date_col, cfg.date_col])
    edate = cfg.event_date_col if cfg.event_date_col in events.columns else cfg.date_col
    if edate not in events.columns:
        return out
    event_dates = events[edate].dropna().dt.normalize().unique()
    state_dates = out[cfg.date_col].dt.normalize()
    out.loc[state_dates.isin(event_dates), cfg.event_flag_col] = 1
    return out

def safe_zscore(series):
    s = pd.to_numeric(series, errors="coerce")
    std = s.std(ddof=0)
    if std is None or np.isnan(std) or std < 1e-9:
        return pd.Series(np.zeros(len(s)), index=s.index, dtype="float64")
    return (s - s.mean()) / (std + 1e-9)

def build_alt_exec_empirical(df):
    work = pd.DataFrame(index=df.index)
    work["sg_component"] = safe_zscore(df["SG_tau"]).clip(lower=0) if "SG_tau" in df.columns else 0.0
    if "FAI" in df.columns:
        work["fai_component"] = safe_zscore(df["FAI"]).clip(lower=0)
    elif "Phi_tau" in df.columns:
        work["fai_component"] = safe_zscore(df["Phi_tau"]).clip(lower=0)
    else:
        work["fai_component"] = 0.0
    if "CER" in df.columns:
        work["cer_component"] = safe_zscore(df["CER"]).clip(lower=0)
    elif "CP_proxy" in df.columns:
        work["cer_component"] = safe_zscore(df["CP_proxy"]).clip(lower=0)
    else:
        work["cer_component"] = 0.0
    return (0.35*work["sg_component"] + 0.35*work["fai_component"] + 0.30*work["cer_component"]).clip(lower=0)

def enrich_panel(df, cfg):
    out = df.copy()
    if "Theta_tau" in out.columns:
        theta_base = pd.to_numeric(out["Theta_tau"], errors="coerce").fillna(0.0)
    elif "A" in out.columns:
        theta_base = pd.to_numeric(out["A"], errors="coerce").fillna(0.0)
    else:
        theta_base = pd.Series(0.0, index=out.index)
    out["ALT_EXEC_emp"] = build_alt_exec_empirical(out)
    out["Theta_eff"] = (theta_base * (1.0 - 0.5 * out["ALT_EXEC_emp"])).clip(lower=0)
    if "CER" in out.columns:
        cp_base = pd.to_numeric(out["CER"], errors="coerce").fillna(0.0)
    elif "CP_proxy" in out.columns:
        cp_base = pd.to_numeric(out["CP_proxy"], errors="coerce").fillna(0.0)
    elif "FAI" in out.columns:
        cp_base = pd.to_numeric(out["FAI"], errors="coerce").fillna(0.0)
    else:
        cp_base = pd.Series(0.0, index=out.index)
    out["CP_eff"] = cp_base * (1.0 + 0.5 * out["ALT_EXEC_emp"])
    out["dSG_tau"] = pd.to_numeric(out["SG_tau"], errors="coerce").diff() if "SG_tau" in out.columns else 0.0
    if cfg.target_col not in out.columns:
        if "Stress" in out.columns:
            future = pd.to_numeric(out["Stress"], errors="coerce").shift(-1)
            thr = future.quantile(0.75)
            out[cfg.target_col] = (future >= thr).astype(int)
        else:
            out[cfg.target_col] = 0
    return out

def run_event_study_v4(df, cfg, variables=None):
    variables = variables or ["R_star","SG_tau","Theta_eff","CP_eff","ALT_EXEC_emp","Stress"]
    work = df.copy().reset_index(drop=True)
    events = work.index[work[cfg.event_flag_col] == 1].tolist()
    rows = []
    for idx in events:
        for var in variables:
            if var not in work.columns:
                continue
            for rel in range(-cfg.event_pre_window, cfg.event_post_window + 1):
                j = idx + rel
                if 0 <= j < len(work):
                    rows.append({"event_index": idx, "relative_day": rel, "variable": var, "value": work.loc[j, var], "date": work.loc[j, cfg.date_col] if cfg.date_col in work.columns else j})
    out = pd.DataFrame(rows)
    if out.empty:
        return out
    return out.groupby(["relative_day","variable"])["value"].mean().reset_index().sort_values(["variable","relative_day"])

def fit_classifier(train_df, feature_cols, target_col):
    pipe = Pipeline(steps=[("imputer", SimpleImputer(strategy="median")), ("scaler", StandardScaler()), ("model", LogisticRegression(max_iter=3000, solver="lbfgs"))])
    pipe.fit(train_df[feature_cols].astype(float), train_df[target_col].astype(int))
    return pipe

def rolling_oos_comparison(df, cfg):
    work = coerce_datetime(df, [cfg.date_col]).sort_values(cfg.date_col).dropna(subset=[cfg.date_col]).reset_index(drop=True)
    features_full = [c for c in cfg.feature_cols_full if c in work.columns]
    features_base = [c for c in cfg.feature_cols_baseline if c in work.columns]
    work = work.dropna(subset=[cfg.target_col, *features_full, *features_base]).reset_index(drop=True)
    if len(work) <= cfg.rolling_window + cfg.rolling_step:
        raise ValueError("Dataset too short for rolling out-of-sample validation.")
    summary_rows, pred_rows = [], []
    for start in range(0, len(work) - cfg.rolling_window - cfg.rolling_step + 1, cfg.rolling_step):
        train = work.iloc[start:start+cfg.rolling_window].copy()
        test = work.iloc[start+cfg.rolling_window:start+cfg.rolling_window+cfg.rolling_step].copy()
        full_model = fit_classifier(train, features_full, cfg.target_col)
        base_model = fit_classifier(train, features_base, cfg.target_col)
        y_test = test[cfg.target_col].astype(int).values
        full_score = full_model.predict_proba(test[features_full].astype(float))[:,1]
        base_score = base_model.predict_proba(test[features_base].astype(float))[:,1]
        full_pred = (full_score >= 0.5).astype(int)
        base_pred = (base_score >= 0.5).astype(int)
        def _safe_auc(y, s): return float(roc_auc_score(y, s)) if len(np.unique(y)) > 1 else np.nan
        summary_rows.append({
            "train_start": str(train[cfg.date_col].iloc[0]), "train_end": str(train[cfg.date_col].iloc[-1]),
            "test_start": str(test[cfg.date_col].iloc[0]), "test_end": str(test[cfg.date_col].iloc[-1]),
            "full_auc": _safe_auc(y_test, full_score), "base_auc": _safe_auc(y_test, base_score),
            "full_f1": float(f1_score(y_test, full_pred, zero_division=0)), "base_f1": float(f1_score(y_test, base_pred, zero_division=0)),
            "full_accuracy": float(accuracy_score(y_test, full_pred)), "base_accuracy": float(accuracy_score(y_test, base_pred)),
        })
        for i, idx in enumerate(test.index):
            pred_rows.append({"date": str(test.loc[idx, cfg.date_col]), "y_true": int(y_test[i]), "full_score": float(full_score[i]), "base_score": float(base_score[i]), "full_pred": int(full_pred[i]), "base_pred": int(base_pred[i])})
    summary_df, pred_df = pd.DataFrame(summary_rows), pd.DataFrame(pred_rows)
    comparison = {
        "mean_full_auc": float(summary_df["full_auc"].mean()) if not summary_df.empty else np.nan,
        "mean_base_auc": float(summary_df["base_auc"].mean()) if not summary_df.empty else np.nan,
        "mean_full_f1": float(summary_df["full_f1"].mean()) if not summary_df.empty else np.nan,
        "mean_base_f1": float(summary_df["base_f1"].mean()) if not summary_df.empty else np.nan,
        "mean_full_accuracy": float(summary_df["full_accuracy"].mean()) if not summary_df.empty else np.nan,
        "mean_base_accuracy": float(summary_df["base_accuracy"].mean()) if not summary_df.empty else np.nan,
        "full_minus_base_auc": float(summary_df["full_auc"].mean() - summary_df["base_auc"].mean()) if not summary_df.empty else np.nan,
    }
    return {"window_summary": summary_df, "predictions": pred_df, "comparison": comparison, "features_full": features_full, "features_baseline": features_base}

def optimize_decision_threshold(y_true, y_score, threshold_grid_size=201):
    thresholds = np.linspace(0.0, 1.0, threshold_grid_size)
    rows = []; best = None
    for thr in thresholds:
        pred = (y_score >= thr).astype(int)
        row = {"threshold": float(thr), "precision": float(precision_score(y_true, pred, zero_division=0)), "recall": float(recall_score(y_true, pred, zero_division=0)), "f1": float(f1_score(y_true, pred, zero_division=0))}
        rows.append(row)
        if best is None or row["f1"] > best["f1"]:
            best = row
    table = pd.DataFrame(rows)
    best_pred = (y_score >= best["threshold"]).astype(int)
    return {"best": best, "table": table, "confusion_matrix": confusion_matrix(y_true, best_pred).tolist()}

def _plot_event_study(event_df, output_dir):
    files = []
    if event_df.empty: return files
    for var, sub in event_df.groupby("variable"):
        fig, ax = plt.subplots(figsize=(8,4))
        ax.plot(sub["relative_day"], sub["value"]); ax.axvline(0, linestyle="--")
        ax.set_title(f"Event Study — {var}"); ax.set_xlabel("Relative day"); ax.set_ylabel(var)
        out = output_dir / f"event_study_{var}.png"
        fig.tight_layout(); fig.savefig(out, dpi=160); plt.close(fig); files.append(str(out))
    return files

def _plot_roc(pred_df, output_dir):
    if pred_df.empty or len(np.unique(pred_df["y_true"])) < 2: return None
    fpr_f, tpr_f, _ = roc_curve(pred_df["y_true"], pred_df["full_score"])
    fpr_b, tpr_b, _ = roc_curve(pred_df["y_true"], pred_df["base_score"])
    fig, ax = plt.subplots(figsize=(5,5))
    ax.plot(fpr_f, tpr_f, label="Full"); ax.plot(fpr_b, tpr_b, label="Baseline"); ax.plot([0,1],[0,1], linestyle="--")
    ax.set_title("ROC Comparison"); ax.set_xlabel("False Positive Rate"); ax.set_ylabel("True Positive Rate"); ax.legend()
    out = output_dir / "roc_comparison.png"
    fig.tight_layout(); fig.savefig(out, dpi=160); plt.close(fig)
    return str(out)

def _plot_thresholds(thr_df, output_dir):
    fig, ax = plt.subplots(figsize=(8,4))
    ax.plot(thr_df["threshold"], thr_df["precision"], label="Precision")
    ax.plot(thr_df["threshold"], thr_df["recall"], label="Recall")
    ax.plot(thr_df["threshold"], thr_df["f1"], label="F1")
    ax.set_title("Threshold Optimization"); ax.set_xlabel("Threshold"); ax.legend()
    out = output_dir / "threshold_curve.png"
    fig.tight_layout(); fig.savefig(out, dpi=160); plt.close(fig)
    return str(out)

def write_empirical_results_section(comparison, best_threshold, output_path):
    lines = [
        "# Empirical Results", "", "## Model comparison",
        f"- Full model mean AUC: **{comparison['mean_full_auc']:.4f}**" if comparison["mean_full_auc"] == comparison["mean_full_auc"] else "- Full model mean AUC: n/a",
        f"- Baseline mean AUC: **{comparison['mean_base_auc']:.4f}**" if comparison["mean_base_auc"] == comparison["mean_base_auc"] else "- Baseline mean AUC: n/a",
        f"- Full model mean F1: **{comparison['mean_full_f1']:.4f}**" if comparison["mean_full_f1"] == comparison["mean_full_f1"] else "- Full model mean F1: n/a",
        f"- Baseline mean F1: **{comparison['mean_base_f1']:.4f}**" if comparison["mean_base_f1"] == comparison["mean_base_f1"] else "- Baseline mean F1: n/a",
        "", "## Threshold optimization",
        f"- Best threshold: **{best_threshold['threshold']:.4f}**",
        f"- Precision: **{best_threshold['precision']:.4f}**",
        f"- Recall: **{best_threshold['recall']:.4f}**",
        f"- F1: **{best_threshold['f1']:.4f}**",
        "", "## Interpretation",
        "The full model should deliver incremental early-warning value relative to the baseline if execution-coherence variables contain real predictive content."
    ]
    output_path = Path(output_path); output_path.write_text("\n".join(lines), encoding="utf-8"); return str(output_path)

def run_validation_v4_bundle(ds_cfg, cfg=None):
    cfg = cfg or ValidationV4Config()
    output_dir = Path(cfg.output_dir); output_dir.mkdir(parents=True, exist_ok=True)
    tables = load_and_harmonize_sources(ds_cfg, cfg)
    master = build_master_state_panel(tables, cfg)
    aligned = align_events_to_panel(master, tables.get("events"), cfg)
    panel = enrich_panel(aligned, cfg)
    event_summary = run_event_study_v4(panel, cfg)
    rolling_result = rolling_oos_comparison(panel, cfg)
    pred_df = rolling_result["predictions"]
    threshold_result = optimize_decision_threshold(pred_df["y_true"].values, pred_df["full_score"].values, cfg.threshold_grid_size)
    panel.to_csv(output_dir / "state_panel_final.csv", index=False)
    event_summary.to_csv(output_dir / "event_study_summary.csv", index=False)
    rolling_result["window_summary"].to_csv(output_dir / "rolling_window_summary.csv", index=False)
    pred_df.to_csv(output_dir / "rolling_predictions.csv", index=False)
    threshold_result["table"].to_csv(output_dir / "threshold_table.csv", index=False)
    figures = []
    figures.extend(_plot_event_study(event_summary, output_dir))
    roc_path = _plot_roc(pred_df, output_dir)
    if roc_path: figures.append(roc_path)
    figures.append(_plot_thresholds(threshold_result["table"], output_dir))
    empirical_md = write_empirical_results_section(rolling_result["comparison"], threshold_result["best"], output_dir / "empirical_results_section.md")
    report = {"comparison": rolling_result["comparison"], "best_threshold": threshold_result["best"], "features_full": rolling_result["features_full"], "features_baseline": rolling_result["features_baseline"], "figures": figures, "empirical_results_md": empirical_md}
    (output_dir / "validation_v4_report.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    return {"tables": tables, "state_panel_final": panel, "event_summary": event_summary, "rolling_result": rolling_result, "threshold_result": threshold_result, "report": report}
