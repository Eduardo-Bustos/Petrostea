import streamlit as st
from validation.validation_engine_v4 import DataSourceConfig, ValidationV4Config, run_validation_v4_bundle

def render_validation_v4_tab():
    st.subheader("Validation Layer v4")
    dataset_master = st.text_input("dataset_master", value="dataset_master_v50_operational.xlsx")
    merged_master = st.text_input("merged_master", value="master_v50_merged_corrected.xlsx")
    state_metrics = st.text_input("state_metrics", value="Table_1_state_metrics-2.xlsx")
    transmission_window = st.text_input("transmission_window", value="Table_2_market_transmission_window.xlsx")
    event_paths = st.text_area("event_paths (one per line)", value="event_study_sg_v41-1.xlsx\nevent_study_rstar.xlsx\nevent_study_ssi_extended.xlsx\nevent_study_theta_collapse.xlsx\nevent_study_fai_v41.xlsx")
    scenarios_path = st.text_input("scenarios", value="scenarios_v41-1.xlsx")
    simulated_paths_path = st.text_input("simulated_paths", value="simulated_paths_v41-1.xlsx")
    output_dir = st.text_input("output_dir", value="outputs/validation_v4")
    if st.button("Run Validation v4"):
        ds_cfg = DataSourceConfig(
            dataset_master_path=dataset_master,
            merged_master_path=merged_master,
            state_metrics_path=state_metrics,
            transmission_window_path=transmission_window,
            event_paths=[x.strip() for x in event_paths.splitlines() if x.strip()],
            scenarios_path=scenarios_path,
            simulated_paths_path=simulated_paths_path,
        )
        cfg = ValidationV4Config(output_dir=output_dir)
        result = run_validation_v4_bundle(ds_cfg, cfg)
        st.markdown("### Model comparison")
        st.json(result["report"]["comparison"])
        st.markdown("### Best threshold")
        st.json(result["report"]["best_threshold"])
        st.markdown("### Rolling windows")
        st.dataframe(result["rolling_result"]["window_summary"], use_container_width=True)
        st.markdown("### Event study summary")
        st.dataframe(result["event_summary"], use_container_width=True)
        st.success("Validation v4 completed.")
